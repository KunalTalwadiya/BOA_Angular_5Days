import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sa-delete',
  templateUrl: './sa-delete.component.html',
  styleUrls: ['./sa-delete.component.scss']
})
export class SaDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
