import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ba-withdraw',
  templateUrl: './ba-withdraw.component.html',
  styleUrls: ['./ba-withdraw.component.scss']
})
export class BaWithdrawComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
