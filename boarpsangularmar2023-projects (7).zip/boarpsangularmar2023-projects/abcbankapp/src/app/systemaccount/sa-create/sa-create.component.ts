import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sa-create',
  templateUrl: './sa-create.component.html',
  styleUrls: ['./sa-create.component.scss']
})
export class SaCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
