import {Employee} from "./employee";


export const empData:Employee[]=[
  new Employee("Parameswari","L7"),
  new Employee("Bala","L6"),
  new Employee("vignesh","L5"),
  new Employee("Shyam","L6"),
  new Employee("Arun","L7"),
]
