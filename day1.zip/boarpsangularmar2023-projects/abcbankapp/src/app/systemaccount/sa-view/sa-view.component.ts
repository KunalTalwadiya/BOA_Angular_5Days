import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sa-view',
  templateUrl: './sa-view.component.html',
  styleUrls: ['./sa-view.component.scss']
})
export class SaViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
