import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ba-transfer',
  templateUrl: './ba-transfer.component.html',
  styleUrls: ['./ba-transfer.component.scss']
})
export class BaTransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
