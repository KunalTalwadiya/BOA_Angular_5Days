import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ba-directdebit',
  templateUrl: './ba-directdebit.component.html',
  styleUrls: ['./ba-directdebit.component.scss']
})
export class BaDirectdebitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
