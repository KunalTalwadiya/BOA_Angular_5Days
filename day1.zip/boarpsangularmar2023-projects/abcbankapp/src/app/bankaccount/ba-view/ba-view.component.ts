import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ba-view',
  templateUrl: './ba-view.component.html',
  styleUrls: ['./ba-view.component.scss']
})
export class BaViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
