import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ba-edit',
  templateUrl: './ba-edit.component.html',
  styleUrls: ['./ba-edit.component.scss']
})
export class BaEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
