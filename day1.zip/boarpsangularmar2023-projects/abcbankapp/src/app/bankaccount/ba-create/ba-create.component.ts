import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ba-create',
  templateUrl: './ba-create.component.html',
  styleUrls: ['./ba-create.component.scss']
})
export class BaCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
