export const environment = {
  production: false,
  link:'http://staging',
  name:'staging environment',
  code: 1003,
};
