export const environment = {
  production: false,
  link:'http://testing',
  name:'testing environment',
  code: 1002,
};
