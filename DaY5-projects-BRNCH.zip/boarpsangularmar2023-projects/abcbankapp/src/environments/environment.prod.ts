export const environment = {
  production: true,
  link:'http://production',
  name:'staging environment',
  code: 1001,
};
