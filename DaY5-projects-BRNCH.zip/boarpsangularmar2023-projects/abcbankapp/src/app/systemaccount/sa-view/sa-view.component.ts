import { Component, OnInit } from '@angular/core';
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-sa-view',
  templateUrl: './sa-view.component.html',
  styleUrls: ['./sa-view.component.scss']
})
export class SaViewComponent implements OnInit {

  assets = []
  constructor() { }

  ngOnInit(): void {

  }

}
