import {Project} from "./project";


export const projectData:Project[]=[new Project(Math.random()*1000,'Banking'),
  new Project(Math.random()*1000,'Insurance'),
  new Project(Math.random()*1000,'Travel'),
    new Project(Math.random()*1000,'Ecommerce')

]
