package com.virtusa.banking.kycprocess.models;

public class Message {

	private String secretMsg;
	private String key;
	public String getSecretMsg() {
		return secretMsg;
	}
	public void setSecretMsg(String secretMsg) {
		this.secretMsg = secretMsg;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	
}
