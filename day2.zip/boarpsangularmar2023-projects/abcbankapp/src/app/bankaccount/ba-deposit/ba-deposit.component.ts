import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ba-deposit',
  templateUrl: './ba-deposit.component.html',
  styleUrls: ['./ba-deposit.component.scss']
})
export class BaDepositComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
