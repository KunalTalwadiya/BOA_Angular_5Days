import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ba-delete',
  templateUrl: './ba-delete.component.html',
  styleUrls: ['./ba-delete.component.scss']
})
export class BaDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
