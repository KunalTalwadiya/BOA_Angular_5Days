import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {MenuComponent} from "./menu/menu.component";
import {BaCreateComponent} from "./bankaccount/ba-create/ba-create.component";
import {BaEditComponent} from "./bankaccount/ba-edit/ba-edit.component";
import {BaViewComponent} from "./bankaccount/ba-view/ba-view.component";
import {BaDeleteComponent} from "./bankaccount/ba-delete/ba-delete.component";
import {BaTransferComponent} from "./bankaccount/ba-transfer/ba-transfer.component";
import {BaDepositComponent} from "./bankaccount/ba-deposit/ba-deposit.component";
import {BaWithdrawComponent} from "./bankaccount/ba-withdraw/ba-withdraw.component";
import {BankComponent} from "./bankaccount/bank/bank.component";
import {BaDirectdebitComponent} from "./bankaccount/ba-directdebit/ba-directdebit.component";

const routes: Routes = [
  {

      path: 'BankAccount',
      component:BankComponent,
      children:[{
        path: 'Create',
        component: BaCreateComponent
      },
        {
          path: 'Edit',
          component: BaEditComponent
        },
        {
          path: 'View',
          component: BaViewComponent
        },
        {
          path: 'Delete',
          component: BaDeleteComponent
        },
        {
          path: 'Transfer',
          component: BaTransferComponent
        },
        {
          path: 'Deposit',
          component: BaDepositComponent
        },
        {
          path: 'Withdraw',
          component: BaWithdrawComponent
        },
        {
          path: 'DirectDebit',
          component: BaDirectdebitComponent
        }
      ]
    },
      {
        path:'SystemAccount',
        loadChildren: () => import('./systemaccount/systemaccount.module')
          .then(m => m.SystemAccountModule)
      }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
