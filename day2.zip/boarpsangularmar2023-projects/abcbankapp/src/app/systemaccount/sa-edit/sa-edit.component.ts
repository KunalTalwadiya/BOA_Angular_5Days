import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sa-edit',
  templateUrl: './sa-edit.component.html',
  styleUrls: ['./sa-edit.component.scss']
})
export class SaEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
